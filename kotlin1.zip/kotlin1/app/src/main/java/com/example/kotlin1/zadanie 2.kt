package com.example.kotlin1

/**
 * Zwraca część wspólną dwóch multizbiorów z uwzględnieniem liczby powtórzeń.
 *
 * Dla każdego elementu sprawdza, czy występuje w drugiej liście, i jeśli tak – dodaje go do wyniku.
 * Każdy wspólny element zostaje dodany tyle razy, ile wynosi minimum jego wystąpień w obu listach.
 *
 * @param x pierwsza lista liczb całkowitych (multizbiór)
 * @param y druga lista liczb całkowitych (multizbiór)
 * @return lista zawierająca część wspólną obu list
 * @throws IllegalArgumentException jeśli którakolwiek z list jest pusta lub null
 */

fun wspolne(x: List<Int>?, y: List<Int>?): List<Int> {
    if (x.isNullOrEmpty() || y.isNullOrEmpty()) {
        throw IllegalArgumentException("Listy nie mogą być puste lub null.")
    }
    val wspolnaczesc = mutableListOf<Int>()
    //pusta edytowalna lista do ktorej bedziemy wrzucac wspolne czesci
    val edytowalnalistay = mutableListOf<Int>()

    for (czesc in y) {
        edytowalnalistay.add(czesc)
    }

    for (czesc in x) {
        if (czesc in edytowalnalistay) {
            wspolnaczesc.add(czesc)
            edytowalnalistay.remove(czesc)
        }
    }
    return wspolnaczesc
}

fun main() {

    println("test funkcji dla prawidlowych danych:")
    val x = listOf(1, 2, 3, 4, 4, 4)
    val y = listOf(3, 4, 4, 5, 5, 6)

    val wspolnota = wspolne(x, y)
    if (wspolnota == listOf(3, 4, 4)) {
        println("funkcja dziala poprawnie wynik to: $wspolnota")
    }else println("BLAD! funkcja nie dziala poprawnie")

    println("test warunkow brzegowych:")
    println("dla pustej listy:")

    try{
        wspolne(emptyList(),listOf(1,2,3,4))
    }
    catch(e:IllegalArgumentException){
        println("funkcja dziala poprawnie")
    }

    println("dla listy null:")

    try{
        wspolne(null,listOf(1,2,3,4))
    }
    catch(e:IllegalArgumentException){
        println("funkcja dziala poprawnie")
    }

    println("dla dwoch pustych list:")

    try{
        wspolne(emptyList(),emptyList())
    }
    catch(e:IllegalArgumentException){
        println("funkcja dziala poprawnie")
    }
    println("dla pustej listy i listy null:")

    try{
        wspolne(null,emptyList())
    }
    catch(e:IllegalArgumentException){
        println("funkcja dziala poprawnie")
    }

}
//zrodla
//odpowiedz chata gpt na pytanie "czym ma byc multizbior, tablica?"
//odpowiedź to "lista"

//odpowiedz czata gpt na pytanie "jak sprawdzic poprawnosc argumentow tej funkcji?"
//odpowiedz to:
// if (x == null || y == null) {
//        throw IllegalArgumentException("Listy nie mogą być nullami.") }
//    if (x.isEmpty() || y.isEmpty()) {
//        throw IllegalArgumentException("Listy nie mogą być puste.") }
//albo:
//if (x.isNullOrEmpty() || y.isNullOrEmpty()) {
//   throw IllegalArgumentException("Listy nie mogą być puste lub null.") }

//kotlin automatycznie podpowiedzial aby dodać znaki zapytania w linijce 5

//odpowiedz czata gpt na pytanie "co zrobic aby moc edytowac liste?"
//odpowiedz to:
//zrobic nowa mutablelist z wartosciami poprzedniej