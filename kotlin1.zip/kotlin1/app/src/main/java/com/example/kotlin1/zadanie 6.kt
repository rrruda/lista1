package com.example.kotlin1

/**
 * Zwraca sekwencję nici matrycowej DNA na podstawie nici kodującej.
 *
 * Nici DNA składają się z zasad: A (adenina), T (tymina), C (cytozyna), G (guanina).
 * Zasady te łączą się komplementarnie:
 * A ↔ T, C ↔ G.
 *
 * @param nickodujaca sekwencja nici kodującej DNA, składająca się wyłącznie z wielkich liter A, T, C, G.
 * @return sekwencja komplementarna (nić matrycowa DNA).
 * @throws IllegalArgumentException jeśli ciąg wejściowy jest pusty lub zawiera inne znaki niż A, T, C, G.
 *
 * Przykład:
 * komplement("AATTGCGCT") → "TTAACGCGA"
 */
fun komplement(nickodujaca: String): String {
    val odpowiedniki = mapOf(
        'A' to 'T',
        'T' to 'A',
        'G' to 'C',
        'C' to 'G'
    )
    if (!nickodujaca.all { it in odpowiedniki.keys }) {
        throw IllegalArgumentException("BLAD! sekwencja nici kodujacej DNA może składać się tylko ze znaków: A,T,C,G")
    }
    if (nickodujaca.isEmpty()) {
        throw IllegalArgumentException("BLAD! sekwencja nici kodujacej DNA nie moze być pusta")
    }

    val nicmatrycowa = nickodujaca.map { nukleotyd -> odpowiedniki[nukleotyd] }

    return nicmatrycowa.joinToString("")
}

/**
* Transkrybuje nić matrycową DNA do odpowiadającej jej sekwencji RNA.
*
* Podczas transkrypcji:
* - A (adenina) → U (uracyl)
* - T (tymina) → A
* - C (cytozyna) → G
* - G (guanina) → C
*
* @param nicmatrycowa sekwencja nici matrycowej DNA, składająca się z wielkich liter A, T, C, G.
* @return sekwencja RNA powstała z nici matrycowej.
* @throws IllegalArgumentException jeśli ciąg wejściowy jest pusty lub zawiera niepoprawne znaki.
*
* Przykład:
* transkrybuj("AATTGCGCT") → "UUAACGCGA"
*/
fun transkrybuj(nicmatrycowa: String): String {
    val odpowiedniki = mapOf(
        'A' to 'U',
        'T' to 'A',
        'G' to 'C',
        'C' to 'G'
    )
    if (!nicmatrycowa.all { it in odpowiedniki.keys }) {
        throw IllegalArgumentException("BLAD! sekwencja nici matrycowej DNA może składać się tylko ze znaków: A,T,C,G")
    }
    if (nicmatrycowa.isEmpty()) {
        throw IllegalArgumentException("BLAD! sekwencja nici matrycowej DNA nie moze być pusta")
    }

    val rna = nicmatrycowa.map { nukleotyd -> odpowiedniki[nukleotyd] }

    return rna.joinToString("")
}

fun main() {

    println("test funkcji komplement: ")

    println("dla poprawnej nici kodujacej:")

    val nic1 = "AATTGCGCT"
    val uzupelnionanic1 = "TTAACGCGA"
    val tocowyszlo1 = komplement(nic1)
    if (tocowyszlo1 == uzupelnionanic1) {
        println("funkcja dziala poprawnie funkcja - nic komplementarna do nici kodujacej: $nic1 to nic matrycowa: $uzupelnionanic1")
    } else println("BLAD! funkcja nie dziala poprawnie")

    println("dla nici kodujacej skladajacej sie z malych liter:")
    try {
        komplement("aattgcgct")
        println("BLAD! nie wykryto malych  liter w nici kodujacej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("dla nici kodujacej zawierajacej nieprawidlowe litery:")
    try {
        komplement("AATFGCGCT")
        println("BLAD! nie wykryto nieprawidlowych liter w nici kodujacej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("dla pustej nici kodujacej:")
    try {
        komplement("")
        println("BLAD! nie wykryto pustej nici kodujacej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }


    println("test funkcji transkrybuj: ")

    println("dla poprawnej nici matrycowej:")

    val nic2 = "AATTGCGCT"
    val uzupelnionanic2 = "UUAACGCGA"
    val tocowyszlo2 = transkrybuj(nic2)
    if (tocowyszlo2 == uzupelnionanic2) {
        println("funkcja dziala poprawnie funkcja - nic komplementarna do nici matrycowej: $nic2 to nic RNA: $uzupelnionanic2")
    } else println("BLAD! funkcja nie dziala poprawnie")

    println("dla nici matrycowej skladajacej sie z malych liter:")
    try {
        transkrybuj("aattgcgct")
        println("BLAD! nie wykryto malych  liter w nici matrycowej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("dla nici matrycowej zawierajacej nieprawidlowe litery:")
    try {
        transkrybuj("AATFGCGCT")
        println("BLAD! nie wykryto nieprawidlowych liter w nici matrycowej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("dla pustej nici matrycowej:")
    try {
        transkrybuj("")
        println("BLAD! nie wykryto pustej nici matrycowej")
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

}

//żródłą:
//pytanie do chata gpt: co zrobić aby funkcja if wykonywała to co ma wykonywać w momencie NIE spełnienia warunku -> znak "!" neguje warunek
//pytanie do chata gpt: na jakich niciach kodujących mogę przeprowadzić test aby sprawdzić warunki brzegowe -> poprawna nić, nić z małych liter, nić zawierająca niepoprawne znaki, pusta nić
//pytanie do chata gpt: co zrobic jak .joinTo String oddziela mi przecinkiem wartości zapisane w mapie -> zadeklaruj separator jako ("")




