package com.example.kotlin1

import kotlin.math.sqrt

/**
 * Oblicza pole trójkąta na podstawie długości jego boków, wykorzystując wzór Herona.
 *
 * @param a długość pierwszego boku (musi być > 0)
 * @param b długość drugiego boku (musi być > 0)
 * @param c długość trzeciego boku (musi być > 0)
 * @return pole trójkąta
 * @throws IllegalArgumentException jeśli dane są niepoprawne lub trójkąt nie istnieje
 */

fun heron(a: Double, b: Double, c: Double): Double {
    //funckja pobiera 3 wartości, będące długościami boków i w tym wypadku (Double) będące liczbami zmiennoprzecinkowymi
    //fukcja zwraca liczbę zmiennoprzecinkową (pole trojkata)

    if (a <= 0 || b <= 0 || c <= 0) {
        throw IllegalArgumentException("warunki poczatkowe nie zostaly spelnione - boki musza być wieksze od zera")
    }

    if (a + b <= c || a + c <= b || b + c <= a) {
        throw IllegalArgumentException("warunki poczatkowe nie zostaly spelnione - z podanych bokow nie da sie zbudowac trojkata")
        //funkcja if w tym wypadku zwraca informacje o bledzie
    }

    var p: Double = a + b + c
    p = p / 2
    //zmienna p przechowuje wartość równą połowie obwodu, potrzebną do wzoru herona

    val S = sqrt(p * (p - a) * (p - b) * (p - c)).toDouble()
    return S
}

/**
 * Testuje funkcję `heron()` na przykładach poprawnych i brzegowych.
 * W przypadku błędów lub niepoprawnych danych funkcja powinna rzucić wyjątek.
 */

//czy zrobić test w fun main() czy w osobnej funkcji
fun main() {

    println("testowanie funkcji dla trojkata 3,4,5: ")

       val pole= heron(3.0, 4.0, 5.0)
    if (pole==6.0)
        println("funkcja dziala poprawnie -> pole trojkata o bokach 3,4,5 to 6")
    else println("BLAD! funkcja nie dziala poprawnie")

    println("testowanie funkcji dla trojkata 0,1,2: ")
    try {
        heron(0.0, 1.0, 2.0)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie -> nie istnieje trojkat o boku 0")
    }

    println("testowanie funkcji dla trojkata 1,2,100: ")
    try {
        heron(1.0, 2.0, 100.0)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie -> nie istnieje trojkat o bokach 1,2,100")
    }
}
//zrodla
//odpowiedz chata gpt na pytanie "co zrobic aby funkcja bo komunikacie o niespelnieniu warunkow poczatkowych przerwac dzialanie funkcji?
//odpowiedzia bylo: "zamiast println() użyj throw IllegalArgumentException()"

//odpowiedz chata gpt na pytanie "jak powinna wygladac dokumentacja kotlin do tego kodu?"