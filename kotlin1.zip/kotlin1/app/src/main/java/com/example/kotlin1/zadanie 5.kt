package com.example.kotlin1
/**
 * Zwraca pełen ciąg Collatza w postaci listy liczb całkowitych.
 *
 * @param c0 liczba początkowa ciągu (musi być większa od 0)
 * @return lista kolejnych liczb w ciągu Collatza
 * @throws IllegalArgumentException jeśli c0 <= 0
 */
fun collatz(c0: Int): List<Int> {
    if (c0 <= 0) {
        throw IllegalArgumentException("parametr c0 musi być liczbąa naturalna wieksza od 0")
    }
    val ciag = mutableListOf(c0)//bo od niej zaczyna sie ciag
    var c = c0// kazdy kolejny numer elementu ciagu

    while (c != 1) {//jka c=1 to pętla się kończy
        if (c % 2 == 0) {
            c = c / 2
        } else c = 3 * c + 1
        ciag.add(c)
    }
    return ciag
}
/**
 * Oblicza długość ciągu Collatza, czyli liczbę elementów od c0 do 1.
 *
 * @param c0 liczba początkowa ciągu (musi być większa od 0)
 * @return liczba elementów w ciągu
 * @throws IllegalArgumentException jeśli c0 <= 0
 */
fun collatzdlugosc(c0: Int): Int {
    if (c0 <= 0) {
        throw IllegalArgumentException("parametr c0 musi być liczbąa naturalna wieksza od 0")
    }
    var c = c0// kazdy kolejny numer elementu ciagu
    var dlugosc = 1//poczatkowa dlugosc

    while (c != 1) {//jka c=1 to pętla się kończy
        if (c % 2 == 0) {
            c = c / 2
        } else c = 3 * c + 1
        dlugosc++
    }
    return dlugosc
}
/**
 * Oblicza największą wartość występującą w ciągu Collatza dla podanego c0.
 *
 * @param c0 liczba początkowa ciągu (musi być większa od 0)
 * @return największy element pojawiający się w ciągu Collatza
 * @throws IllegalArgumentException jeśli c0 <= 0
 */
fun collatzwartosc(c0:Int):Int{
    if (c0 <= 0) {
        throw IllegalArgumentException("parametr c0 musi być liczbąa naturalna wieksza od 0")
    }
    var c = c0// kazdy kolejny numer elementu ciagu
    var wartosc = c0//poczatkowa maksymalna wartosc

    while (c != 1) {//jka c=1 to pętla się kończy
        if (c % 2 == 0) {
            c = c / 2
        } else c = 3 * c + 1

        if(c>wartosc){
            wartosc=c
        }
    }
    return wartosc
}

fun main() {
    println("test poprawnego ciagu:")
    var poprawnyciag = collatz(7)
    if (poprawnyciag == listOf(7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1)) {
        println("funkcja dziala poprawnie dla c0=7 ciag collatza to :$poprawnyciag")
    } else println("BLAD! funkcja nie dziala poprawnie")

    println("test warunkowe brzegowych dla c0=0 i c0=-3:")

    try {
        collatz(0)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie dla c0=0")
    }

    try {
        collatz(-3)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie dla c0=-3")
    }

    println("oblicza maksymalna dlugosc ciagu:")
    var maxdlugosc = 0
    var c0dlamaxdlugosc = 0

    for (i in 1..100000) {
        val dlugosc = collatzdlugosc(i)
        if (dlugosc > maxdlugosc) {
            maxdlugosc = dlugosc
            c0dlamaxdlugosc = i
        }
    }
    println("dla liczby c0 do wartosci 1.000.000 maksymalna dlugosc ciagu collatza wynosi $maxdlugosc dla c0= $c0dlamaxdlugosc")

    println("oblicza maksymalna wartosc ciagu:")
    var maxwartosc = 0
    var c0dlamaxwartosc = 0

    for (i in 1..100000) {
        val wartosc = collatzwartosc(i)
        if (wartosc > maxdlugosc) {
            maxdlugosc = wartosc
            c0dlamaxdlugosc = i
        }
    }
    println("dla liczby c0 do wartosci 1.000.000 maksymalna wartosc elementu ciagu collatza wynosi $c0dlamaxwartosc dla c0= $c0dlamaxwartosc")

}


//źródła:
//pytanie do chata gpt: jaką pętle wykorzystać żeby wykonywała się tak długo aż mój parametr osiągnie jakąs wartość -> while
//pytanie do chata gpt: w jakim zakresie c0 powinnam szukać najwiekszej wartości ciągu i najdłuższego ciągu? -> 10.000/10.000/1.000.000
//kod zajmowal za duzo pamieci ram chat gpt podpowiedzial ze da się to zrobić prościej dla 1.000.000 -> "Zamiast tworzyć cały ciąg jak wcześniej, wystarczy w pętli zliczać długość i zapamiętywać największą wartość, jaka pojawi się podczas obliczeń."
/*println("oblicza maksymalna dlugosc ciagu:")

    var maxdlugosc=0
    var c0dlamaxdlugosc=0

    for(i in 1..1000000){
        val dlugosc=collatz(i).size
        if (dlugosc>maxdlugosc){
            maxdlugosc=dlugosc
            c0dlamaxdlugosc=i
        }
    }
    println("dla liczby c0 do wartosci 1.000.000 maksymalna dlugosc ciagu collatza wynosi $maxdlugosc dla c0= $c0dlamaxdlugosc")
*/ //
//podpowiedział aby zrobić do tego nową funkcję