package com.example.kotlin1

/**
 * Zwraca listę n pierwszych elementów ciągu Fibonacciego obliczoną iteracyjnie.
 *
 * @param n liczba elementów ciągu do wygenerowania. Musi być większa lub równa 1.
 * @return lista zawierająca n pierwszych liczb Fibonacciego.
 * @throws IllegalArgumentException jeśli n < 1.
 *
 * Przykład:
 * fibonacciiteracja(5) → [0, 1, 1, 2, 3]
 */

fun fibonacciiteracja(n: Int): List<Int> {

    if (n < 1) {
        throw IllegalArgumentException("liczba elementow ciagu fibonacciego musi byc wieksza lub rowna 1")
    }
    val ciag = mutableListOf(0)

    if (n == 1) return ciag

    ciag.add(1)

    if (n == 2) return ciag
    else {
        for (i in 2..n - 1) {//bo listy tez sa numerowane od 0
            val elementciagu = ciag[i - 1] + ciag[i - 2]
            ciag.add(elementciagu)
        }
    }
    return ciag
}

/**
 * Zwraca wartość n-tego elementu ciągu Fibonacciego obliczoną rekurencyjnie.
 * Funkcja zakłada, że numeracja elementów zaczyna się od 1:
 * element(1) = 0, element(2) = 1, itd.
 *
 * @param n numer elementu (licząc od 1). Musi być większy lub równy 1.
 * @return wartość n-tego elementu ciągu.
 * @throws IllegalArgumentException jeśli n < 1.
 */

fun element(n:Int):Int{
    //pobiera n-ty i zwraca wartosc
    if (n < 1) {
        throw IllegalArgumentException("liczba elementow ciagu fibonacciego musi byc wieksza lub rowna 1")
    }
    if(n==1){return 0}//zawsze tak bedzie
    if(n==2){return 1}//zawsze tak bedzie

    else{return (element(n-1)+element(n-2))}//bo sie  numeruje od 0
}

/**
 * Zwraca listę n pierwszych elementów ciągu Fibonacciego obliczoną rekurencyjnie
 * (każdy element liczony przez funkcję `element()`).
 *
 * @param n liczba elementów ciągu do wygenerowania. Musi być większa lub równa 1.
 * @return lista zawierająca n pierwszych liczb Fibonacciego.
 * @throws IllegalArgumentException jeśli n < 1.
 *
 * Przykład:
 * fibonaccirekursja(5) → [0, 1, 1, 2, 3]
 */

fun fibonaccirekursja(n:Int):List<Int>{
    if (n < 1) {
        throw IllegalArgumentException("liczba elementow ciagu fibonacciego musi byc wieksza lub rowna 1")
    }
    val ciag= mutableListOf<Int>()
    for( i in 1..n){
        ciag.add(element(i))
    }
    return ciag
}

fun main() {
    val ciagitestowe = listOf(
        Pair(1, listOf(0)),
        Pair(2, listOf(0, 1)),
        Pair(3, listOf(0, 1, 1)),
        Pair(7, listOf(0, 1, 1, 2, 3, 5, 8))
    )

    println("FUNKCJA ITERACYJNA:")

    for ((i, j) in ciagitestowe) {
        val ciag = fibonacciiteracja(i)
        if (ciag == j) {
            println("funkcja dziala poprawnie dla n=$i ciag wyglada tak: $ciag")
        } else println("BŁĄD! funkcja niie dziala poprawnie")
    }

    println("test warunkow brzegowych: 0 i -1")
    println("dla 0: ")
    try {
        fibonacciiteracja(0)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }
    println("dla -1: ")
    try {
        fibonacciiteracja(-1)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("FUNKCJA REKURENCYJNA:")

    for ((i, j) in ciagitestowe) {
        val ciag = fibonaccirekursja(i)
        if (ciag == j) {
            println("funkcja dziala poprawnie dla n=$i ciag wyglada tak: $ciag")
        } else println("BŁĄD! funkcja niie dziala poprawnie")
    }

    println("test warunkow brzegowych: 0 i -1")
    println("dla 0: ")
    try {
        fibonaccirekursja(0)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }
    println("dla -1: ")
    try {
        fibonaccirekursja(-1)
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }
}

//źródła:
//pytanie do chata gpt: jak dodać element do listy -> lista.add(element)
//pytanie do chata gpt: jak przetestowac funkcje -> zaproponowal rozwiazanie z listą par, gdzie para skłąda się z liczby n oraz ciagu)
//pytanie do chata gpt: jak przetestowac warunki brzegowe -> try/catch
//pytanie do chata gpt: na czym polega rekursja i czym różni się od iteracji
//pytanie do chata gpt: jak zrobic pusta mutablelistof() -> mutableListOf<Int>()