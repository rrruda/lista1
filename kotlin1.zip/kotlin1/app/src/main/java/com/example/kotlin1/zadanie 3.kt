package com.example.kotlin1

/**
* Generuje wszystkie niepuste podzbiory danego zbioru.
*
* Ta funkcja wykorzystuje reprezentację binarną liczb, aby
* stworzyć wszystkie możliwe kombinacje elementów wejściowego zbioru.
* Pusty zbiór nie jest uwzględniany w wyniku.
*
* @param zbior zbiór elementów, z których mają zostać wygenerowane podzbiory
* @return lista zawierająca wszystkie niepuste podzbiory zbioru wejściowego
* @throws IllegalArgumentException jeśli wejściowy zbiór jest pusty
*
* @sample
* val zbior = setOf(1, 2, 3)
* val wynik = podzbiory(zbior)
* println(wynik)
* // Wynik: [[1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]
*/

fun <T> podzbiory(zbior: Set<T>): List<Set<T>> {

    if (zbior.isEmpty()) {
        throw IllegalArgumentException("zbior nie może być pusty")
    }
    val lista = zbior.toList()
    val podzbiory = mutableListOf<Set<T>>()
    val n = lista.size
    val liczbapozdbiorow = Math.pow(2.0, n.toDouble()).toInt()


    for (i in 1..liczbapozdbiorow-1) {
        val podzbior = mutableSetOf<T>()//tworzę pusty Set który zostanie stworzony tyle razy ile ma być podzbiorów


        for (j in 0..n - 1) {
            //przechodzimy po każdym elemencie listy - dlatego, że listy numerowane są od 0
            //ta pętla for sprawdza, czy element "j" (czyli każdy po kolei/każdy aktualnie sprawdzany) ma znajdować się w aktualnym podzbiorze stworzonym w pętli nadrzędnej for
            if ((i shr j) and 1 == 1)
            //tego nie rozumiem ale chciałam kontynuować kod
                podzbior.add(lista[j])
            //Czy w binarnej reprezentacji liczby i bit na pozycji j jest równy 1?”
            //Jeśli tak, to dodajemy lista[j] do aktualnego podzbioru.
        }
        podzbiory.add(podzbior)
    }
    return podzbiory
}

fun main(){
    println("test funkcji podzbiory:")

    try {
        println("dla pustego zbioru")
        val pusty = emptySet<Int>()
        println(podzbiory(pusty))
    } catch (e: IllegalArgumentException) {
        println("funkcja dziala poprawnie")
    }

    println("dla jednoelementowego zbioru")
    val jeden = setOf("A")
    val wynik1 = podzbiory(jeden)
    println("funkcja dziala poprawnie - podzbiory zbioru $jeden to: $wynik1")

    println("dla dwuelementowego zbioru")
    val dwa = setOf("A", "B")
    val wynik2 = podzbiory(dwa)
    println("funkcja dziala poprawnie - podzbiory zbioru $dwa to: $wynik2")

    println("dla piecioelementowego (normalnego) zbioru")
    val piec = setOf(1, 2, 3, 4, 5)
    val wynik5 = podzbiory(piec)
    println("funkcja dziala poprawnie - podzbiory zbioru $piec to: $wynik5")
}


//zródła
//pytanie do chata gpt: czego użyć do zrobienia zbioru w kotlinie? -> Set
//pytanie do chata gpt: jak spradzic czy Set nie zawiera powtórzeń -> nigdy nie zawiera nie trzeba tego sprawdzać
//chat gpt podpowiedział zeby zamienic Set na List w 8 linijce kodu bo lista ma ponumerowane pola a Set nie
//chat gpt pomógł z pętlą for, któa wykorzystuje kod binarny, jednak wszystko zrozumiałam i podpisałam



